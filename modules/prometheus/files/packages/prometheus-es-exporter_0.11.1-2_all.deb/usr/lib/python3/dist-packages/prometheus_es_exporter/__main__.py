from prometheus_es_exporter import main

if __name__ == '__main__':
    main()
